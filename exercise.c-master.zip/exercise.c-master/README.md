# exercise.c
#include <stdio.h>
int main()
{
	
/*exo 20*/
		int N1;
		     printf("Exo 20:Nombre de données : ");
	     scanf("%d", &N1);



	     do
	       {
	         printf("Nombre de données : ");
	         scanf("%d", &N1);
	       }
	     while(N1<1 || N1>15);
	 /*Comme l'introduction du nombre de données doit toujours être exécuté (au moins une fois), le plus naturel sera l'utilisation de la structure do - while.*/



	/*exo 1*/
	/*1)*/int COMPTEUR;
	/*2)*/char X,Y;
	/*3)*/int MESURE;
	/*4)*/float surface1;
	/*5)*/double surface2;
	/*6)*/int N0;
	/*7)*/int N01;
	/*8)*/long N3;
	/*9)*/double N4;
	/*10)*/int TROUVE;
	
	
	
 
				
/*exo21*/
	int i6,n8;
	int fact;
	do{
	printf("exo21: entrer un entier\n ");
	scanf("%d",&n8);}
	while(n8<0);
	
	i6=1;
	fact=1;
	while(i6<=n8)
{	fact=fact*i6;
	i6++;
}
	
	printf("la factorielle est %d\n",fact);	


	/*exo22*/
	int X6,N6,I6,RES;
	do{
	printf("exo22: entrer un entier naturel X\n ");
	scanf("%d",&X6);}
	while(X6<0);
	do{
	printf("entrer un exposant N\n ");
	scanf("%d",&N6);}
	while(N6<0);
	for(I6=0;I6<=N6;I6++)
	{
		RES=RES*X6;
	}
	if(N6==0 && X6==0){printf("operation non définie\n ");}
	else
{	printf("resultat: %d \n",RES);
}
		


	/*exo23:*/
	int cpt1,n6;
	float resu;
	printf("exo23:saisir les n premiers termes\n ");
	scanf("%d",&n6);
	resu=0;
	for(cpt1=1;cpt1<=n6;cpt1++)
	{
	resu=resu+(float)1/cpt1;
	}
	printf("res=%f\n",resu);

	/*exo24*/
	 int  X5;    
 	 int  N5=0;   
	 int  SOM5=0;  
	 long PROD5=1; 
              

 do
    {
      /* Saisie des données (pour perfectionnistes) */
     printf("exo24:Entrez le %d%s chiffre : ", (N5+1), (N5)?"e":"er");
     scanf("%d", &X5);

     if (X5<0||X5>9)
        printf("\a");
     else if (X5)
        {
         N5++;
         SOM5+=X5;
         PROD5*=X5;
        }
     else if (!X5 && N5>0)
         {/* Seulement si au moins un chiffre a été accepté */
         printf("La somme   des chiffres est %d \n", SOM5);
         printf("Le produit des chiffres est %ld\n", PROD5);
         printf("La moyenne des chiffres est %f \n", (float)SOM5/N5);
        }
    }
 while (X);
	/*exo 25*/
int  X3;       /* Le chiffre courant   */     
/* long  N4=0;     /* Le compteur des décimales */
 long VALD=1;  /* Valeur de la position décimale courante */
 long NOMB3=0;  /* Le nombre résultat */                     
 do
    {
      printf("Entrez le %s chiffre : ", (N4+1), (N4)?"e":"er");
     scanf("%d", &X3);

     if (X3<0||X3>9)
        printf("\a");
     else if (X3)
        {
         NOMB3 += VALD*X3;
         N3++;
         VALD *= 10;
        }
     else
        printf("La valeur du nombre renversé est %ld\n", NOMB3);


